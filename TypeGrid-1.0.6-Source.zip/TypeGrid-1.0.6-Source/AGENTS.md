<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the supplied TypeGrid handoff as a self-contained static interface under `public/typegrid/`; the app lives at the `/app` route (embeds `public/typegrid/windows.html`) so the browser preview and desktop package share the same UI, while `/` is the typegrid.site marketing landing.
- Keep local note persistence in the renderer for browser preview and use the Electron preload bridge for native atomic disk saving, clipboard, export, and window controls; this preserves offline use without a server.
- Keep TypeGrid entirely offline: no AI endpoints, remote fonts, or network-dependent note features; bundled fonts ship locally and imported fonts stay in the existing local state, preserving the user’s local-only vision.
- Android build wraps public/typegrid via Capacitor with platform='android' plus scripts/android.css (removes preview phone frame); Store package via scripts/build_msix.py with identity from MSIX_* env vars — keeps one shared UI for all platforms.
- Download files (exe/tar.gz/apk) live in the private storage bucket `typegrid-downloads` (public buckets are blocked); `/api/public/downloads/$file` mints a per-request signed URL — never copy the installers into public/.
