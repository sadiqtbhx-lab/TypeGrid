# Roadmap

- [x] Redesign typegrid.site landing page (Classic Editorial) — TypeGrid-Website-Redesign.zip
- [x] Privacy policy page for typegrid.site (privacy.html in the zip) — link https://www.typegrid.site/privacy.html in Store submission
- [x] Android: beams animation disabled on Android
- [x] Android: copy/cut glitch fixed (rich editor)
- [x] New notes start empty (no auto Untitled note)
- [x] Welcome screen shows once only
- [x] Rebuilt Android APK+AAB v1.0.3 with fixes
- [ ] Publish site on www.typegrid.site (in progress: marketing landing + /privacy + /app + download route; needs domain DNS + publish)
- [ ] Rebuild MSIX with real Partner Center identity (blocked: needs user values)
- [x] Fix editor footer (word count/zoom) floating mid-page with dead space below in maximized Windows window
- [x] Fix empty-notes screen heading clipped under titlebar / Create-note button overlapping sidebar
- [x] Welcome screen not showing after fresh install (first launch should show it)
- [x] Speed up in-app animations (too slow on Windows)
- [x] Website: add logo + replace empty mockup with real app screenshot
- [x] Build macOS + Linux versions
- [x] Single zip with all versions — TypeGrid-All-Versions-1.0.5.zip (682 MB, 7 builds)
- [ ] Upload project to GitHub
- [x] Add custom font import and 22 bundled offline fonts; rebuild signed Android 1.0.5 APK+AAB

- [x] Replace the TypeGrid logo across the website and shared app; rebuild all-platform download folder
- [x] Show Windows, Android, macOS, and Linux consistently throughout the in-app Welcome, Settings, and About screens
- [x] Full release QA, confirmed bug fixes, final-version labeling, and all-platform ZIP delivery — TypeGrid 1.0.6 Final
