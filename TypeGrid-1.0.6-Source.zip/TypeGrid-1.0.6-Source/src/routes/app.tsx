import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/app")({
  head: () => ({
    meta: [
      { title: "TypeGrid — Fast Autosaving Notes" },
      {
        name: "description",
        content:
          "TypeGrid is a private, local notes workspace with instant saving, rich editing, and personal and work profiles.",
      },
      { property: "og:title", content: "TypeGrid — Fast Autosaving Notes" },
      {
        property: "og:description",
        content: "Capture ideas instantly with TypeGrid's local, autosaving notes workspace.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AppPage,
});

function AppPage() {
  return (
    <iframe
      title="TypeGrid notes workspace"
      src="/typegrid/windows.html"
      className="block h-dvh w-full border-0 bg-background"
      allow="clipboard-read; clipboard-write"
    />
  );
}
