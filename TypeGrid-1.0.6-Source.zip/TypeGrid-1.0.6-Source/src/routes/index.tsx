import { createFileRoute, Link } from "@tanstack/react-router";
import logo from "@/assets/typegrid-logo-blue.png.asset.json";
import winDemo from "@/assets/typegrid-win-demo.png.asset.json";
import androidDemo from "@/assets/typegrid-android-demo.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&family=Figtree:wght@400;500&display=swap",
      },
    ],
    meta: [
      { title: "TypeGrid — Offline Notes for Windows, Android, macOS & Linux" },
        {
          name: "description",
          content:
            "TypeGrid is a minimalist, fully offline notes app for Windows, Android, macOS and Linux. Autosaved on every keystroke, ultra-lightweight, and private by design. Free download.",
        },
        { property: "og:title", content: "TypeGrid — Write Without Friction" },
        {
          property: "og:description",
          content:
            "Fast autosaving notes for Windows, Android, macOS and Linux. 100% free & offline.",
        },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Landing,
});

const SITE_CSS = `
:root{--paper:#F9F7F2;--card:#FFFFFF;--ink:#2D3331;--muted:#5A6361;--mint:#168578;--mint-dark:#126B60;--line:#E5E2DA}
.tg-site{background:var(--paper);color:var(--ink);font-family:'Figtree',sans-serif;line-height:1.6;-webkit-font-smoothing:antialiased;min-height:100dvh}
.tg-site *{margin:0;padding:0;box-sizing:border-box}
.tg-site h1,.tg-site h2,.tg-site h3,.tg-site .btn,.tg-site .brand{font-family:'Outfit',sans-serif}
.tg-site a{color:var(--mint)}
.tg-site .wrap{max-width:1120px;margin:0 auto;padding:0 24px}
.tg-site nav{position:sticky;top:0;z-index:10;background:rgba(249,247,242,.9);backdrop-filter:blur(8px);border-bottom:1px solid var(--line)}
.tg-site nav .wrap{display:flex;align-items:center;justify-content:space-between;height:64px}
.tg-site .brand{font-weight:700;font-size:20px;color:var(--ink);text-decoration:none;letter-spacing:-.02em;display:inline-flex;align-items:center;gap:10px}
.tg-site .brand img{width:34px;height:34px;object-fit:contain}
.tg-site .brand b{font-weight:700}
.tg-site .brand span{color:var(--mint)}
.tg-site .navlinks{display:flex;gap:28px;align-items:center}
.tg-site .navlinks a{color:var(--muted);text-decoration:none;font-size:14px;font-weight:500}
.tg-site .navlinks a:hover{color:var(--mint)}
.tg-site .btn,.tg-site .navlinks a.btn{display:inline-block;background:var(--mint);color:#fff;text-decoration:none;font-weight:600;padding:12px 28px;border-radius:10px;transition:background .2s,transform .15s;border:0;cursor:pointer;font-size:16px}
.tg-site .btn:hover,.tg-site .navlinks a.btn:hover{background:var(--mint-dark);color:#fff;transform:translateY(-1px)}
.tg-site .btn.sm{padding:8px 18px;font-size:14px}
.tg-site .btn.ghost{background:transparent;color:var(--mint);border:1px solid var(--mint)}
.tg-site .btn.ghost:hover{background:var(--mint);color:#fff}
.tg-site .hero{text-align:center;padding:96px 24px 64px;max-width:820px;margin:0 auto}
.tg-site .badge{display:inline-flex;align-items:center;gap:8px;padding:6px 16px;border-radius:999px;background:rgba(22,133,120,.08);color:var(--mint);font-size:13px;font-weight:500;letter-spacing:.04em;border:1px solid rgba(22,133,120,.2)}
.tg-site .badge::before{content:"";width:7px;height:7px;border-radius:50%;background:var(--mint)}
.tg-site .hero h1{font-size:clamp(40px,6vw,64px);font-weight:700;letter-spacing:-.03em;line-height:1.08;color:var(--mint);margin:28px 0 20px}
.tg-site .hero p{font-size:19px;color:var(--muted);max-width:560px;margin:0 auto 36px}
.tg-site .hero .actions{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}
.tg-site .hero .note{margin-top:18px;font-size:13px;color:var(--muted);letter-spacing:.06em;text-transform:uppercase}
.tg-site .plat{display:grid;grid-template-columns:1fr 1fr;gap:48px;max-width:960px;margin:0 auto;align-items:start}
.tg-site .pcol{display:flex;flex-direction:column;align-items:center;gap:8px}
.tg-site .pbadge{width:64px;height:64px;border-radius:18px;background:rgba(22,133,120,.08);border:1px solid rgba(22,133,120,.22);display:flex;align-items:center;justify-content:center;margin-bottom:4px}
.tg-site .pbadge svg{width:32px;height:32px;fill:var(--mint)}
.tg-site .pcol h3{font-size:20px;font-weight:600;color:var(--ink)}
.tg-site .pcol .psub{color:var(--muted);font-size:14px;margin-bottom:10px}
.tg-site .pshot{background:var(--card);border:1px solid var(--line);border-radius:16px;box-shadow:0 28px 56px -24px rgba(22,133,120,.28);overflow:hidden;width:100%;max-width:520px}
.tg-site .pshot img{display:block;width:100%;height:auto}
.tg-site .pshot.phone{max-width:282px;border:10px solid #22302d;border-radius:38px;box-shadow:0 28px 56px -24px rgba(22,133,120,.4)}
.tg-site .pcol .btn{margin-top:6px}
.tg-site section.block{padding:88px 0}
.tg-site .eyebrow{text-align:center;font-size:12px;font-weight:600;letter-spacing:.28em;text-transform:uppercase;color:var(--mint);margin-bottom:14px}
.tg-site h2.center{text-align:center;font-size:clamp(28px,4vw,40px);font-weight:700;letter-spacing:-.02em;margin-bottom:12px}
.tg-site .sub{text-align:center;color:var(--muted);max-width:560px;margin:0 auto 48px}
.tg-site .dgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;max-width:960px;margin:0 auto}
.tg-site .dcard{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:32px 28px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:6px;transition:border-color .2s,transform .2s,box-shadow .2s}
.tg-site .dcard:hover{border-color:rgba(22,133,120,.4);transform:translateY(-2px);box-shadow:0 20px 40px -20px rgba(22,133,120,.2)}
.tg-site .dcard .dicon{width:56px;height:56px;border-radius:14px;background:rgba(22,133,120,.08);display:flex;align-items:center;justify-content:center;margin-bottom:12px}
.tg-site .dcard .dicon svg{width:28px;height:28px;fill:var(--mint)}
.tg-site .dcard h3{font-size:20px;font-weight:600;color:var(--ink)}
.tg-site .dcard .meta{color:var(--muted);font-size:14px;margin-bottom:16px}
.tg-site .dcard .btn{width:100%}
.tg-site .dcard.soon:hover{transform:none;box-shadow:none;border-color:var(--line)}
.tg-site .soon-pill{display:inline-block;padding:9px 22px;border-radius:10px;border:1px dashed rgba(22,133,120,.45);color:var(--mint);font-family:'Outfit';font-weight:600;font-size:14px;letter-spacing:.06em;text-transform:uppercase;background:rgba(22,133,120,.05)}
.tg-site .dnote{margin-top:22px;text-align:center;color:var(--muted);font-size:14px}
.tg-site .dnote a{font-weight:500}
.tg-site .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.tg-site .fcard{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:30px;transition:border-color .2s,transform .2s}
.tg-site .fcard:hover{border-color:rgba(22,133,120,.4);transform:translateY(-2px)}
.tg-site .fcard h3{font-size:19px;font-weight:600;color:var(--mint);margin-bottom:10px}
.tg-site .fcard p{color:var(--muted);font-size:15px}
.tg-site .specs{display:grid;grid-template-columns:repeat(4,1fr);gap:24px;text-align:center}
.tg-site .spec b{display:block;font-family:'Outfit';font-size:30px;color:var(--mint);letter-spacing:-.02em}
.tg-site .spec span{font-size:13px;color:var(--muted);text-transform:uppercase;letter-spacing:.12em}
.tg-site .creator{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:56px;text-align:center;max-width:820px;margin:0 auto}
.tg-site .creator h2{font-size:clamp(26px,3.5vw,36px);font-weight:700;letter-spacing:-.02em;margin:10px 0 14px}
.tg-site .creator p{color:var(--muted);max-width:520px;margin:0 auto 22px}
.tg-site .creator a{font-weight:500;text-decoration:underline;text-underline-offset:4px;text-decoration-color:rgba(22,133,120,.3)}
.tg-site .creator a:hover{text-decoration-color:var(--mint)}
.tg-site footer{border-top:1px solid var(--line);padding:36px 0;margin-top:88px}
.tg-site footer .wrap{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;font-size:14px;color:var(--muted)}
.tg-site footer a{color:var(--muted);text-decoration:none;margin-left:22px}
.tg-site footer a:hover{color:var(--mint)}
@media(max-width:860px){
  .tg-site .grid{grid-template-columns:1fr 1fr}
  .tg-site .dgrid{grid-template-columns:1fr;max-width:440px}
  .tg-site .plat{grid-template-columns:1fr;gap:56px;max-width:560px}
  .tg-site .specs{grid-template-columns:1fr 1fr;gap:32px}
  .tg-site .preview .side{display:none}
  .tg-site .navlinks a:not(.btn){display:none}
}
@media(max-width:560px){.tg-site .grid{grid-template-columns:1fr}.tg-site .creator{padding:34px 22px}.tg-site .hero{padding:72px 20px 52px}.tg-site .wrap{padding:0 18px}}
`;

function WindowsIcon() {
  return (
    <svg viewBox="0 0 24 24">
      <path d="M3 5.5 10.5 4.4v7.1H3V5.5zm0 13 7.5 1.1v-7H3v5.9zM11.5 4.2 21 3v8.5h-9.5V4.2zm0 15.6L21 21v-8.5h-9.5v7.3z" />
    </svg>
  );
}

function AndroidIcon() {
  return (
    <svg viewBox="0 0 24 24">
      <path d="M17.5 8.6l1.4-2.4c.1-.2 0-.4-.2-.5s-.4 0-.5.2l-1.4 2.4C15.7 7.5 14.4 7 13 7s-2.7.5-3.8 1.2L7.8 5.9c-.1-.2-.3-.2-.5-.2-.2.1-.3.3-.2.5l1.4 2.4C6.4 9.7 5 11.7 5 14h14c0-2.3-1.4-4.3-3.5-5.4zM13 17.5c0 .6-.4 1-1 1s-1-.4-1-1v-2.5h2v2.5zm-6 0c0 .6-.4 1-1 1s-1-.4-1-1v-2.5h2v2.5zm12 0c0 .6-.4 1-1 1s-1-.4-1-1v-2.5h2v2.5zM5 15c0 1.7 1.3 3 3 3h8c1.7 0 3-1.3 3-3H5z" transform="translate(0 1.5) scale(.92)" />
    </svg>
  );
}

function StoreIcon() {
  return (
    <svg viewBox="0 0 24 24">
      <path d="M18 6h-2V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v1H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zM9 5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1H9V5zm10 3v2h-6v-2H6v9h12v-3h-4v-1h4V8h1z" opacity=".55" />
      <path d="M12 10.5h8v3.5a2 2 0 0 1-2 2h-6v-5.5z" />
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg viewBox="0 0 24 24">
      <path d="M16.7 12.8c0-2.4 2-3.6 2.1-3.7-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-1.9-.9-3.2-.9-1.6 0-3.1 1-4 2.4-1.7 2.9-.4 7.3 1.2 9.7.8 1.2 1.8 2.5 3 2.4 1.2 0 1.7-.8 3.1-.8s1.9.8 3.2.8c1.3 0 2.2-1.2 3-2.4.9-1.4 1.3-2.7 1.3-2.8-.1 0-2.5-1-2.5-3.7zM14.6 5.4c.7-.8 1.1-1.9 1-3-1 0-2.1.6-2.8 1.4-.6.7-1.1 1.9-1 2.9 1.1.1 2.2-.5 2.8-1.3z" />
    </svg>
  );
}

function LinuxIcon() {
  return (
    <svg viewBox="0 0 24 24">
      <path d="M12 2c-2 0-3.2 1.6-3.2 3.6 0 1.2.3 2.2.3 3.2 0 1.6-1.4 2.4-1.7 4.2-.1.8.1 1.4-.2 2-.5 1-1.7 1.6-1.9 2.6-.1.8.3 1.4 1 1.7.9.5 2.1.3 3.1.5.9.2 1.5.9 2.6.9s1.7-.7 2.6-.9c1-.2 2.2 0 3.1-.5.7-.3 1.1-.9 1-1.7-.2-1-1.4-1.6-1.9-2.6-.3-.6-.1-1.2-.2-2-.3-1.8-1.7-2.6-1.7-4.2 0-1 .3-2 .3-3.2C15.2 3.6 14 2 12 2zm-2.2 5.2c.4 0 .8.3.8.8s-.4.7-.8.7-.7-.3-.7-.7.3-.8.7-.8zm4.4 0c.4 0 .7.3.7.8s-.3.7-.7.7-.8-.3-.8-.7.4-.8.8-.8z" />
    </svg>
  );
}

function Landing() {
  return (
    <div className="tg-site">
      <style>{SITE_CSS}</style>
      <nav>
        <div className="wrap">
          <Link to="/" className="brand">
            <img src={logo.url} alt="TypeGrid logo" />
            <b>Type<span>Grid</span></b>
          </Link>
          <div className="navlinks">
            <a href="#download">Download</a>
            <a href="#features">Features</a>
            <a href="#specs">Specifications</a>
            <a href="#creator">Creator</a>
            <Link to="/privacy">Privacy</Link>
            <a className="btn sm" href="#download">
              Download — Free
            </a>
          </div>
        </div>
      </nav>

      <header className="hero">
        <span className="badge">TypeGrid 1.0.6 Final — 100% Free &amp; Offline</span>
        <h1>
          Write Without Friction.
          <br />
          Autosaved On Every Keystroke.
        </h1>
        <p>
          A minimalist notes app designed for focus. Everything you type is preserved instantly,
          locally, and securely — no account, no cloud, no waiting.
        </p>
        <div className="actions">
          <a className="btn" href="/api/public/downloads/TypeGrid-Setup-1.0.6.exe">
            Download for Windows
          </a>
          <a className="btn ghost" href="/api/public/downloads/TypeGrid-Android-1.0.6.apk">
            Get it on Android
          </a>
        </div>
        <p className="note">Windows · Android · macOS · Linux — Free forever</p>
      </header>

      <section className="block" id="download">
        <div className="wrap">
          <p className="eyebrow">Get TypeGrid</p>
          <h2 className="center">Download TypeGrid — Free</h2>
          <p className="sub">Every version is completely offline. Your notes never leave your device.</p>
          <div className="dgrid">
            <div className="dcard">
              <div className="dicon">
                <WindowsIcon />
              </div>
              <h3>Windows</h3>
              <p className="meta">Installer · v1.0.6 Final</p>
              <a className="btn" href="/api/public/downloads/TypeGrid-Setup-1.0.6.exe">
                Download .exe
              </a>
            </div>
            <div className="dcard">
              <div className="dicon">
                <AndroidIcon />
              </div>
              <h3>Android</h3>
              <p className="meta">APK · v1.0.6 Final · Android 6.0+</p>
              <a className="btn ghost" href="/api/public/downloads/TypeGrid-Android-1.0.6.apk">
                Download APK
              </a>
            </div>
            <div className="dcard">
              <div className="dicon">
                <AppleIcon />
              </div>
              <h3>macOS</h3>
              <p className="meta">ZIP · v1.0.6 Final · Apple Silicon &amp; Intel</p>
              <a className="btn" href="/api/public/downloads/TypeGrid-macOS-AppleSilicon-1.0.6.zip">
                Download for Mac
              </a>
            </div>
            <div className="dcard">
              <div className="dicon">
                <LinuxIcon />
              </div>
              <h3>Linux</h3>
              <p className="meta">tar.gz · v1.0.6 Final · 64-bit</p>
              <a className="btn" href="/api/public/downloads/TypeGrid-Linux-x64-1.0.6.tar.gz">
                Download for Linux
              </a>
            </div>
            <div className="dcard soon">
              <div className="dicon">
                <StoreIcon />
              </div>
              <h3>Microsoft Store</h3>
              <p className="meta">Verified &amp; auto-updated by Microsoft</p>
              <span className="soon-pill">Coming Soon</span>
            </div>
          </div>
          <p className="dnote">
            On an older Intel Mac? Get the{" "}
            <a href="/api/public/downloads/TypeGrid-macOS-Intel-1.0.6.zip">Intel build</a>. Prefer no
            installation on Windows? Grab the{" "}
            <a href="/api/public/downloads/TypeGrid-Windows-x64-1.0.6.tar.gz">portable version</a> — unzip
            and run TypeGrid.exe.
          </p>
        </div>
      </section>

      <section className="block" id="platforms" style={{ paddingTop: 0 }}>
        <div className="wrap">
          <p className="eyebrow">One App, Every Device</p>
          <h2 className="center">TypeGrid Now Available For All</h2>
          <p className="sub">
            The same quiet writing space on every screen — same autosave, same privacy, same free
            app.
          </p>
          <div className="plat">
            <div className="pcol">
              <div className="pbadge">
                <WindowsIcon />
              </div>
              <h3>Windows</h3>
              <p className="psub">Windows 10 &amp; 11 · installer or portable</p>
              <div className="pshot">
                <img src={winDemo.url} alt="TypeGrid demo screen on Windows" />
              </div>
              <a className="btn" href="/api/public/downloads/TypeGrid-Setup-1.0.6.exe">
                Download for Windows
              </a>
            </div>
            <div className="pcol">
              <div className="pbadge">
                <AndroidIcon />
              </div>
              <h3>Android</h3>
              <p className="psub">Android 6.0+ · phone &amp; tablet</p>
              <div className="pshot phone">
                <img src={androidDemo.url} alt="TypeGrid demo screen on Android" />
              </div>
              <a className="btn ghost" href="/api/public/downloads/TypeGrid-Android-1.0.6.apk">
                Download APK
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="block" id="features" style={{ paddingTop: 0 }}>
        <div className="wrap">
          <p className="eyebrow">Engineering Highlights</p>
          <h2 className="center">Built For Speed, Privacy &amp; Focus</h2>
          <p className="sub">
            Everything you need for lightning-fast personal and professional note-taking.
          </p>
          <div className="grid">
            <div className="fcard">
              <h3>Instant Keystroke Autosave</h3>
              <p>
                Never worry about pressing Ctrl+S or losing your train of thought. TypeGrid commits
                your notes seamlessly on every keystroke with debounced disk persistence.
              </p>
            </div>
            <div className="fcard">
              <h3>100% Offline &amp; Local</h3>
              <p>
                No telemetry, no tracking, and zero reliance on external cloud servers. All your
                notes remain securely stored on your own device.
              </p>
            </div>
            <div className="fcard">
              <h3>Ultra-Lightweight</h3>
              <p>
                Unlike bloated web-wrapped apps that consume gigabytes of RAM, TypeGrid is a
                precision-crafted app that boots in a blink.
              </p>
            </div>
            <div className="fcard">
              <h3>Instant Fuzzy Search</h3>
              <p>
                Instantly search across your entire notes archive as you type. Real-time filtering
                scans both note titles and content simultaneously.
              </p>
            </div>
            <div className="fcard">
              <h3>PDF, Word &amp; Text Export</h3>
              <p>
                Own your data with zero vendor lock-in. One click exports your note to PDF, Word
                (.docx), Markdown, or plain text — anytime.
              </p>
            </div>
            <div className="fcard">
              <h3>Private By Design</h3>
              <p>
                Even we, the publisher, have no access to your notes — there is no server holding
                them and no door for us to open. Nobody can read a single word you write.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="block" id="specs" style={{ paddingTop: 0 }}>
        <div className="wrap">
          <p className="eyebrow">Specifications</p>
          <h2 className="center">Small Numbers, Big Difference</h2>
          <p className="sub">Precision engineering you can feel every time you open the app.</p>
          <div className="specs">
            <div className="spec">
              <b>&lt; 1 s</b>
              <span>Cold start</span>
            </div>
            <div className="spec">
              <b>0</b>
              <span>Accounts required</span>
            </div>
            <div className="spec">
              <b>100%</b>
              <span>Offline &amp; local</span>
            </div>
            <div className="spec">
              <b>∞</b>
              <span>Notes, free forever</span>
            </div>
          </div>
        </div>
      </section>

      <section className="block" id="creator" style={{ paddingTop: 0 }}>
        <div className="wrap">
          <div className="creator">
            <p className="eyebrow" style={{ marginBottom: 0 }}>
              Verified Creator
            </p>
            <h2>A Vision By Yeasin Arafat Sadiq</h2>
            <p>
              Conceptualized, designed and built by one person with a simple philosophy:{" "}
              <em>Built to Solve. Coded to Care.</em> Human-centric software, made independently.
            </p>
            <p>
              <a href="https://www.sadiqtbh.com" target="_blank" rel="noopener noreferrer">
                www.sadiqtbh.com
              </a>
            </p>
          </div>
        </div>
      </section>

      <footer>
        <div className="wrap">
          <span>© 2026 TypeGrid · A Vision By Yeasin Arafat Sadiq</span>
          <span>
            <Link to="/privacy">Privacy Policy</Link>
            <a href="https://www.sadiqtbh.com" target="_blank" rel="noopener noreferrer">
              Creator
            </a>
          </span>
        </div>
      </footer>
    </div>
  );
}
