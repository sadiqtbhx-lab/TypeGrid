import { createFileRoute, Link } from "@tanstack/react-router";
import logo from "@/assets/typegrid-logo-blue.png.asset.json";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&family=Figtree:wght@400;500&display=swap",
      },
    ],
    meta: [
      { title: "Privacy Policy — TypeGrid" },
      {
        name: "description",
        content:
          "TypeGrid privacy policy: no data collection, no account, no analytics, no network access. Your notes never leave your device.",
      },
      { property: "og:title", content: "TypeGrid — Privacy Policy" },
      {
        property: "og:description",
        content: "TypeGrid collects nothing. Your notes never leave your device.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PrivacyPage,
});

const PRIVACY_CSS = `
:root{--paper:#F9F7F2;--card:#FFFFFF;--ink:#2D3331;--muted:#5A6361;--mint:#168578;--mint-dark:#126B60;--line:#E5E2DA}
.tg-privacy{background:var(--paper);color:var(--ink);font-family:'Figtree',sans-serif;line-height:1.7;-webkit-font-smoothing:antialiased;min-height:100dvh}
.tg-privacy *{margin:0;padding:0;box-sizing:border-box}
.tg-privacy h1,.tg-privacy h2,.tg-privacy .brand{font-family:'Outfit',sans-serif}
.tg-privacy a{color:var(--mint)}
.tg-privacy .wrap{max-width:820px;margin:0 auto;padding:0 24px}
.tg-privacy nav{position:sticky;top:0;z-index:10;background:rgba(249,247,242,.9);backdrop-filter:blur(8px);border-bottom:1px solid var(--line)}
.tg-privacy nav .wrap{max-width:1120px;display:flex;align-items:center;justify-content:space-between;height:64px}
.tg-privacy .brand{font-weight:700;font-size:20px;color:var(--ink);text-decoration:none;letter-spacing:-.02em;display:inline-flex;align-items:center;gap:10px}
.tg-privacy .brand img{width:34px;height:34px;object-fit:contain}
.tg-privacy .brand span{color:var(--mint)}
.tg-privacy nav a.back{color:var(--muted);text-decoration:none;font-size:14px;font-weight:500}
.tg-privacy nav a.back:hover{color:var(--mint)}
.tg-privacy header{padding:72px 0 24px}
.tg-privacy .eyebrow{font-size:12px;font-weight:600;letter-spacing:.28em;text-transform:uppercase;color:var(--mint);margin-bottom:14px}
.tg-privacy h1{font-size:clamp(34px,5vw,48px);font-weight:700;letter-spacing:-.02em;margin-bottom:14px}
.tg-privacy .updated{color:var(--muted);font-size:14px}
.tg-privacy .lede{font-size:18px;color:var(--muted);margin:28px 0 8px}
.tg-privacy .policy section{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:28px 30px;margin-top:20px}
.tg-privacy .policy h2{font-size:20px;font-weight:600;color:var(--mint);margin-bottom:8px}
.tg-privacy .policy p{color:var(--muted);font-size:15px}
.tg-privacy .policy p+p{margin-top:10px}
.tg-privacy footer{border-top:1px solid var(--line);padding:36px 0;margin-top:72px}
.tg-privacy footer .wrap{max-width:1120px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:16px;font-size:14px;color:var(--muted)}
.tg-privacy footer a{color:var(--muted);text-decoration:none;margin-left:22px}
.tg-privacy footer a:hover{color:var(--mint)}
`;

const SECTIONS: Array<[string, React.ReactNode]> = [
  [
    "1. Your data stays on your device",
    <p key="p1">
      Every note you write in TypeGrid is stored locally on your own device — in the app's private
      storage area on Windows, Android, macOS, or Linux. Your notes are never uploaded, synced, or
      transmitted anywhere.
    </p>,
  ],
  [
    "2. No account, no sign-up",
    <p key="p2">
      TypeGrid does not ask for your name, email address, phone number, or any other personal
      information. There is no account system, no login screen, and no registration of any kind.
    </p>,
  ],
  [
    "3. No analytics or tracking",
    <p key="p3">
      The app contains no analytics SDKs, no crash-reporting services, no advertising trackers, and
      no usage telemetry. We do not know how many notes you have, what they contain, or how often
      you use the app — and we designed it that way on purpose.
    </p>,
  ],
  [
    "4. No network access",
    <p key="p4">
      TypeGrid works entirely offline. The app makes no network requests for its note-taking
      features. The only links that ever leave the app are the ones you deliberately click (such as
      the creator's website), and those open in your own browser, outside the app.
    </p>,
  ],
  [
    "5. Exports are yours alone",
    <p key="p5">
      When you export a note as PDF, Word (.docx), Markdown, or plain text, the file is created
      locally on your device and saved where you choose. Exported files are never sent to us or to
      any third party.
    </p>,
  ],
  [
    "6. Even we can't see anything about you",
    <p key="p6">
      As the publisher, we have no access to your notes — there is no server holding them and no
      door for us to open. Nobody at TypeGrid, including us, can read a single word you write.
    </p>,
  ],
  [
    "7. Children's privacy",
    <p key="p7">
      Because TypeGrid collects no personal information from anyone, it is safe for users of any
      age. We do not knowingly collect data from children — we collect no data at all.
    </p>,
  ],
  [
    "8. Changes to this policy",
    <p key="p8">
      If this policy ever changes, the updated version will be posted at this address with a new
      "last updated" date, and the change will be noted inside the app. We will never introduce
      data collection without making it unmistakably clear first.
    </p>,
  ],
  [
    "9. Contact",
    <p key="p9">
      Questions about this policy? Reach the creator via{" "}
      <a href="https://www.sadiqtbh.com" target="_blank" rel="noopener noreferrer">
        www.sadiqtbh.com
      </a>
      .
    </p>,
  ],
];

function PrivacyPage() {
  return (
    <div className="tg-privacy">
      <style>{PRIVACY_CSS}</style>
      <nav>
        <div className="wrap">
          <Link to="/" className="brand">
            <img src={logo.url} alt="TypeGrid logo" />
            <b>Type<span>Grid</span></b>
          </Link>
          <Link to="/" className="back">
            ← Back to home
          </Link>
        </div>
      </nav>

      <div className="wrap">
        <header>
          <p className="eyebrow">Legal</p>
          <h1>Privacy Policy</h1>
          <p className="updated">
            Last updated: October 2026 · TypeGrid 1.0.6 Final · Windows, Android, macOS, and Linux
          </p>
          <p className="lede">
            TypeGrid was built on a simple promise: your words belong to you. This policy explains —
            in plain language — exactly what the app does with your data. The short version:{" "}
            <strong>nothing leaves your device, and we collect nothing.</strong>
          </p>
        </header>

        <div className="policy">
          {SECTIONS.map(([title, body]) => (
            <section key={title}>
              <h2>{title}</h2>
              {body}
            </section>
          ))}
        </div>
      </div>

      <footer>
        <div className="wrap">
          <span>© 2026 TypeGrid · A Vision By Yeasin Arafat Sadiq</span>
          <span>
            <Link to="/">Home</Link>
            <a href="https://www.sadiqtbh.com" target="_blank" rel="noopener noreferrer">
              Creator
            </a>
          </span>
        </div>
      </footer>
    </div>
  );
}
