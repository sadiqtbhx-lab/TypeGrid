import { createFileRoute } from "@tanstack/react-router";

// Serves the official TypeGrid download files from private storage.
// Files are held privately; this route mints a short-lived signed URL per
// request so visitors can download them without the files being public.
const FILES = new Set([
  "TypeGrid-Setup-1.0.6.exe",
  "TypeGrid-Windows-x64-1.0.6.tar.gz",
  "TypeGrid-Android-1.0.6.apk",
  "TypeGrid-macOS-AppleSilicon-1.0.6.zip",
  "TypeGrid-macOS-Intel-1.0.6.zip",
  "TypeGrid-Linux-x64-1.0.6.tar.gz",
]);

export const Route = createFileRoute("/api/public/downloads/$file")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const name = params.file;
        if (!FILES.has(name)) {
          return new Response("Not found", { status: 404 });
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data, error } = await supabaseAdmin.storage
          .from("typegrid-downloads")
          .createSignedUrl(name, 300, { download: name });
        if (error || !data?.signedUrl) {
          return new Response("Not found", { status: 404 });
        }
        return new Response(null, {
          status: 302,
          headers: {
            Location: data.signedUrl,
            "cache-control": "no-store",
          },
        });
      },
    },
  },
});
