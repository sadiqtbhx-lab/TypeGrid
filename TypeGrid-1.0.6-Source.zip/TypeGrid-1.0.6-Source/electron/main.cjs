const { app, BrowserWindow, ipcMain, dialog, clipboard, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

const MAX_STATE_BYTES = 64 * 1024 * 1024;
let mainWindow;
const notesPath = () => path.join(app.getPath('userData'), 'notes.json');

function atomicSave(data) {
  if (typeof data !== 'string' || Buffer.byteLength(data, 'utf8') > MAX_STATE_BYTES) return false;
  const target = notesPath();
  const temp = `${target}.tmp`;
  try {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const fd = fs.openSync(temp, 'w');
    try {
      fs.writeFileSync(fd, data, 'utf8');
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(temp, target);
    return true;
  } catch (error) {
    console.error('Could not save notes:', error);
    try { fs.unlinkSync(temp); } catch {}
    return false;
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1320, height: 860, minWidth: 780, minHeight: 600,
    title: 'TypeGrid — Fast Autosaving Notes',
    icon: path.join(__dirname, 'logo.ico'),
    frame: false,
    backgroundColor: '#f5f7f7',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
    },
  });
  mainWindow.loadFile(path.join(__dirname, '..', 'public', 'typegrid', 'windows.html'));
  const allowedLinks = new Set([
    'https://www.typegrid.site',
    'https://typegrid.site',
    'https://www.svgrepo.com',
    'https://creativecommons.org',
    'https://www.sadiqtbh.com',
    'https://sadiqtbh.com',
  ]);
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const parsed = new URL(url);
      if (allowedLinks.has(parsed.origin)) shell.openExternal(url);
    } catch {}
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (url !== mainWindow.webContents.getURL()) event.preventDefault();
  });
}

app.whenReady().then(() => {
  ipcMain.on('typegrid:load', (event) => {
    try { event.returnValue = fs.readFileSync(notesPath(), 'utf8'); }
    catch { event.returnValue = null; }
  });
  ipcMain.on('typegrid:save', (event, data) => { event.returnValue = atomicSave(data); });
  ipcMain.on('typegrid:copy', (event, text) => {
    if (typeof text !== 'string') { event.returnValue = false; return; }
    clipboard.writeText(text); event.returnValue = true;
  });
  ipcMain.handle('typegrid:paste', () => clipboard.readText());
  ipcMain.handle('typegrid:export', async (_, text, suggestedName) => {
    if (typeof text !== 'string' || Buffer.byteLength(text, 'utf8') > MAX_STATE_BYTES) return false;
    const name = path.basename(String(suggestedName || 'TypeGrid-note.txt')).replace(/[<>:"/\\|?*]/g, '_');
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: name.endsWith('.txt') ? name : `${name}.txt`,
      filters: [{ name: 'Text files', extensions: ['txt'] }],
    });
    if (result.canceled || !result.filePath) return false;
    try { fs.writeFileSync(result.filePath, text, 'utf8'); return true; }
    catch { return false; }
  });
  ipcMain.handle('typegrid:export-docx', async (_, b64, suggestedName) => {
    if (typeof b64 !== 'string' || b64.length > MAX_STATE_BYTES * 2) return false;
    const name = path.basename(String(suggestedName || 'TypeGrid-note.docx')).replace(/[<>:"/\\|?*]/g, '_');
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: name.endsWith('.docx') ? name : `${name}.docx`,
      filters: [{ name: 'Word documents', extensions: ['docx'] }],
    });
    if (result.canceled || !result.filePath) return false;
    try { fs.writeFileSync(result.filePath, Buffer.from(b64, 'base64')); return true; }
    catch { return false; }
  });
  ipcMain.handle('typegrid:export-pdf', async (_, html, suggestedName) => {
    if (typeof html !== 'string' || Buffer.byteLength(html, 'utf8') > MAX_STATE_BYTES) return false;
    const name = path.basename(String(suggestedName || 'TypeGrid-note.pdf')).replace(/[<>:"/\\|?*]/g, '_');
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: name.endsWith('.pdf') ? name : `${name}.pdf`,
      filters: [{ name: 'PDF documents', extensions: ['pdf'] }],
    });
    if (result.canceled || !result.filePath) return false;
    let printWin;
    try {
      printWin = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false } });
      await printWin.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
      const pdf = await printWin.webContents.printToPDF({ printBackground: true, pageSize: 'A4' });
      fs.writeFileSync(result.filePath, pdf);
      return true;
    } catch (error) {
      console.error('Could not export PDF:', error);
      return false;
    } finally { if (printWin) printWin.destroy(); }
  });
  ipcMain.on('typegrid:window', (_, action) => {
    if (!mainWindow) return;
    if (action === 'min') mainWindow.minimize();
    if (action === 'max') mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
    if (action === 'close') mainWindow.close();
  });
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
