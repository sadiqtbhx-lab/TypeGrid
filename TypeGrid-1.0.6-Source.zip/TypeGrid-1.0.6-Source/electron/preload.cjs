const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('TypeGridNative', {
  load: () => ipcRenderer.sendSync('typegrid:load'),
  save: (data) => ipcRenderer.sendSync('typegrid:save', data),
  copy: (text) => ipcRenderer.sendSync('typegrid:copy', text),
  paste: () => ipcRenderer.invoke('typegrid:paste'),
  exportText: (text, name) => ipcRenderer.invoke('typegrid:export', text, name),
  exportDocx: (b64, name) => ipcRenderer.invoke('typegrid:export-docx', b64, name),
  exportPdf: (html, name) => ipcRenderer.invoke('typegrid:export-pdf', html, name),
  windowAction: (action) => ipcRenderer.send('typegrid:window', action),
});
