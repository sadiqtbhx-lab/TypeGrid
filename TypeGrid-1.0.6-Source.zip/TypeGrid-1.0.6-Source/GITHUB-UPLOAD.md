# TypeGrid 1.0.6 Final — Source Code for GitHub

This is the complete TypeGrid source code, ready to upload to a GitHub repository.
It contains no dependencies (node_modules), no build output, and no secret keys.

## How to upload to GitHub

### Option A — GitHub website (easiest)
1. Go to https://github.com/new and create a repository (e.g. `typegrid`).
2. Unzip this file on your computer.
3. On your new repo page, click "uploading an existing file".
4. Drag all files and folders from the unzipped folder into the page.
5. Click "Commit changes".

### Option B — Command line
```sh
cd TypeGrid-1.0.6-Source
git init
git add .
git commit -m "TypeGrid 1.0.6 Final"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/typegrid.git
git push -u origin main
```

## Run locally
```sh
npm install
npm run dev
```

## Notes
- The `.env` file is intentionally excluded (it holds environment keys). If you
  run the website locally, create your own `.env` — the desktop/Android app in
  `public/typegrid/` works fully offline without it.
- `electron/` contains the Windows/macOS/Linux desktop wrapper.
- `scripts/` contains the MSIX (Microsoft Store) and Android build helpers.
- Version: 1.0.6 Final · License: MIT (see public/typegrid/LICENSE.txt)
