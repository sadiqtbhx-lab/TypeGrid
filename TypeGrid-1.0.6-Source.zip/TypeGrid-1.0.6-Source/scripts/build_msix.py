import os,sys,zipfile,hashlib,base64,shutil
from PIL import Image
SRC='/tmp/typegrid-v14/TypeGrid-win32-x64'; STAGE='/tmp/msix/stage'; OUT=sys.argv[1]
NAME=os.environ.get('MSIX_NAME','YeasinArafatSadiq.TypeGrid'); PUB=os.environ.get('MSIX_PUBLISHER','CN=YeasinArafatSadiq'); PUBN=os.environ.get('MSIX_PUBLISHER_NAME','Yeasin Arafat Sadiq'); VER='1.0.6.0'
shutil.rmtree(STAGE,ignore_errors=True); shutil.copytree(SRC,STAGE); os.makedirs(STAGE+'/Assets')
logo=Image.open('/mnt/user-uploads/TypeGrid_Logo_Png.png').convert('RGBA'); logo=logo.crop(logo.getbbox())
def mk(w,h,f,frac=.8):
    c=Image.new('RGBA',(w,h),(0,0,0,0)); im=logo.copy(); im.thumbnail((int(min(w,h)*frac),)*2,Image.LANCZOS)
    c.alpha_composite(im,((w-im.width)//2,(h-im.height)//2)); c.save(STAGE+'/Assets/'+f)
for sc in (100,200,400):
    k=sc/100; mk(int(150*k),int(150*k),f'Square150x150Logo.scale-{sc}.png',.7); mk(int(44*k),int(44*k),f'Square44x44Logo.scale-{sc}.png',.9)
    mk(int(310*k),int(150*k),f'Wide310x150Logo.scale-{sc}.png',.7); mk(int(50*k),int(50*k),f'StoreLogo.scale-{sc}.png',.9)
for t in (16,24,32,48,256):
    mk(t,t,f'Square44x44Logo.targetsize-{t}.png',.95); mk(t,t,f'Square44x44Logo.targetsize-{t}_altform-unplated.png',.95)
man=f'''<?xml version="1.0" encoding="utf-8"?>
<Package xmlns="http://schemas.microsoft.com/appx/manifest/foundation/windows10" xmlns:uap="http://schemas.microsoft.com/appx/manifest/uap/windows10" xmlns:rescap="http://schemas.microsoft.com/appx/manifest/foundation/windows10/restrictedcapabilities" IgnorableNamespaces="uap rescap">
  <Identity Name="{NAME}" Publisher="{PUB}" Version="{VER}" ProcessorArchitecture="x64"/>
  <Properties><DisplayName>TypeGrid</DisplayName><PublisherDisplayName>{PUBN}</PublisherDisplayName><Logo>Assets\\StoreLogo.png</Logo><Description>Fast autosaving notes. Fully offline and private.</Description></Properties>
  <Dependencies><TargetDeviceFamily Name="Windows.Desktop" MinVersion="10.0.17763.0" MaxVersionTested="10.0.22621.0"/></Dependencies>
  <Resources><Resource Language="en-us"/></Resources>
  <Applications><Application Id="TypeGrid" Executable="TypeGrid.exe" EntryPoint="Windows.FullTrustApplication">
    <uap:VisualElements DisplayName="TypeGrid" Description="Fast autosaving notes" BackgroundColor="transparent" Square150x150Logo="Assets\\Square150x150Logo.png" Square44x44Logo="Assets\\Square44x44Logo.png"><uap:DefaultTile Wide310x150Logo="Assets\\Wide310x150Logo.png"/></uap:VisualElements>
  </Application></Applications>
  <Capabilities><rescap:Capability Name="runFullTrust"/></Capabilities>
</Package>'''
open(STAGE+'/AppxManifest.xml','w',encoding='utf-8').write(man)
files=[]
for r,_,fs in os.walk(STAGE):
    for f in sorted(fs):
        p=os.path.join(r,f); files.append(os.path.relpath(p,STAGE).replace(os.sep,'/'))
files.sort(key=lambda x:(x!='AppxManifest.xml',x))
bm=['<?xml version="1.0" encoding="UTF-8"?>','<BlockMap xmlns="http://schemas.microsoft.com/appx/2010/blockmap" HashMethod="http://www.w3.org/2001/04/xmlenc#sha256">']
z=zipfile.ZipFile(OUT,'w',zipfile.ZIP_STORED,allowZip64=False)
exts=set(); noext=[]
for rel in files:
    data=open(STAGE+'/'+rel,'rb').read()
    zi=zipfile.ZipInfo(rel,(2024,1,1,0,0,0)); zi.compress_type=zipfile.ZIP_STORED; zi.create_system=0
    z.writestr(zi,data)
    lfh=30+len(rel.encode())
    bm.append(f'<File Name="{rel.replace("/","\\\\").replace("&","&amp;")}" Size="{len(data)}" LfhSize="{lfh}">')
    for i in range(0,max(len(data),1),65536):
        if not data: break
        bm.append(f'<Block Hash="{base64.b64encode(hashlib.sha256(data[i:i+65536]).digest()).decode()}"/>')
    bm.append('</File>')
    e=os.path.splitext(rel)[1][1:].lower()
    if e: exts.add(e)
    else: noext.append(rel)
bm.append('</BlockMap>')
z.writestr(zipfile.ZipInfo('AppxBlockMap.xml',(2024,1,1,0,0,0)),'\n'.join(bm))
ct=['<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">']
types={'xml':'application/xml','png':'image/png','exe':'application/x-msdownload','dll':'application/x-msdownload','json':'application/json','html':'text/html','js':'application/javascript','css':'text/css'}
for e in sorted(exts):
    pass
    ct.append(f'<Default Extension="{e}" ContentType="{types.get(e,"application/octet-stream")}"/>')
for n in noext: ct.append(f'<Override PartName="/{n}" ContentType="application/octet-stream"/>')
ct.append('<Override PartName="/AppxManifest.xml" ContentType="application/vnd.ms-appx.manifest+xml"/><Override PartName="/AppxBlockMap.xml" ContentType="application/vnd.ms-appx.blockmap+xml"/></Types>')
z.writestr(zipfile.ZipInfo('[Content_Types].xml',(2024,1,1,0,0,0)),''.join(ct)); z.close()
print('files',len(files),'size',os.path.getsize(OUT))
